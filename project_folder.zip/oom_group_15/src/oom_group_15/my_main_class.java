package oom_group_15;

import library.assistant.database.database_handler;

public class my_main_class {
	public static void main(String[] args) {
		new database_handler();
		new mainmenu();
	}
}
